<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="¡Envíanos tus datos para poder contactarte y estar al día con la tecnología!">
    <title>Contacto - TechNews360</title>
    <link rel="stylesheet" href="css/style.css">
    <script defer src="js/script.js"></script>
</head>
<body>
    <header class="header" role="banner">
        <div class="brand glow" id="titulo" tabindex="0" aria-label="TechNews360">
            <span class="logo">🌐</span> TechNews360
        </div>
        <nav class="nav" aria-label="Navegación principal">
            <ul class="menu">
                <li><a href="index.php#noticias">Noticias</a></li>
                <li><a href="index.php#videos">Videos</a></li>
                <li><a href="Ranking.php">Ranking</a></li>
                <li><a href="Contacto.php">Contacto</a></li>
            </ul>
        </nav>
    </header>

    <main id="contenido" class="main-content">
        <section id="contacto" class="section">
            <h2>¡Contáctanos!</h2>
            <form id="formulario" action="guardar_contacto.php" method="POST" novalidate aria-describedby="form-help">
                <div class="field">
                    <label for="nombre">Nombre</label>
                    <input type="text" id="nombre" name="nombre" required minlength="2" placeholder="Tu nombre">
                </div>
                <div class="field">
                    <label for="email">Correo</label>
                    <input type="email" id="email" name="email" required placeholder="tu@correo.com">
                </div>
                <div class="field">
                    <label for="mensaje">Mensaje</label>
                    <textarea name="mensaje" id="mensaje" required minlength="10" rows="4" placeholder="Escríbenos tu mensaje"></textarea>
                </div>
                <p id="form-help" class="help"></p>
                <button type="submit" class="btn">Enviar</button>
            </form>
        </section>
    </main>

    <footer class="footer" role="contentinfo">
        <hr>
        <p>&copy; 2025 TechNews360 todos los derechos reservados</p>
    </footer>
</body>
</html>
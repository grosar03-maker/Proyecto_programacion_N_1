// =========================================================================
// ARCHIVO: script.js
// CUMPLE CON TODOS LOS REQUISITOS (CON VALIDACIÓN Y RANKING DINÁMICO)
// =========================================================================

document.addEventListener('DOMContentLoaded', () => {
    console.log("DOM completamente cargado. Inicializando scripts.");

    const noticiasContainer = document.getElementById('noticias-container');
    if (noticiasContainer) {
        cargarNoticias(noticiasContainer, 'obtener_noticias.php');
    }

    const form = document.getElementById('formulario');
    if (form) {
        form.addEventListener('submit', function(ev) {
            manejarEnvioFormulario(ev, this);
        });
    }

    // === INICIO DE LA NUEVA FUNCIONALIDAD PARA RANKING ===
    const rankingContainer = document.getElementById('ranking-dinamico');
    if (rankingContainer) {
        inicializarRankingDinamico();
    }
    // === FIN DE LA NUEVA FUNCIONALIDAD PARA RANKING ===

    inicializarEfectosVisuales();
});

// ========================================================
// FUNCIÓN 1: Cargar noticias usando FETCH
// ========================================================
function cargarNoticias(container, url) {
    console.log(`Iniciando fetch de noticias desde: ${url}`);
    
    fetch(url)
        .then(response => {
            if (!response.ok) throw new Error(`Error HTTP! estado: ${response.status}`);
            return response.json();
        })
        .then(noticias => {
            console.log("Noticias recibidas de la BD:", noticias);
            if (noticias.length === 0) {
                container.innerHTML = '<p>No hay noticias para mostrar en este momento.</p>';
                return;
            }
            
            container.innerHTML = ''; // Limpiar el contenedor

            noticias.forEach(noticia => {
                const card = document.createElement('article');
                card.className = 'card reveal';
                card.setAttribute('aria-labelledby', `title-${noticia.id}`);
                card.innerHTML = `
                    <figure>
                        <img src="${noticia.url_imagen}" alt="${noticia.alt_imagen}" loading="lazy">
                        <figcaption>Foto: Unsplash</figcaption>
                    </figure>
                    <div class="card-body">
                        <h3 id="title-${noticia.id}">${noticia.titulo}</h3>
                        <p>${noticia.descripcion}</p>
                        <p class="meta">Fuente: ${noticia.fuente} — ${noticia.fecha_publicacion}</p>
                        <a class="btn" target="_blank" rel="noopener" href="${noticia.url_noticia}">Leer en ${noticia.fuente}</a>
                    </div>
                `;
                container.appendChild(card);
            });
            
            document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
        })
        .catch(error => {
            console.error('Error al cargar las noticias:', error);
            container.innerHTML = '<p>Hubo un error al cargar las noticias. Revisa la consola para más detalles.</p>';
        });
}

// ========================================================
// FUNCIÓN 2: Manejar el envío del formulario (VERSIÓN ACTUALIZADA)
// ========================================================
function manejarEnvioFormulario(evento, formulario) {
    console.log("Interceptando envío de formulario...");
    evento.preventDefault();

    const submitButton = formulario.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.textContent = 'Enviando...';

    const nombre = formulario.querySelector('#nombre');
    const email = formulario.querySelector('#email');
    const mensaje = formulario.querySelector('#mensaje');
    const helpText = formulario.querySelector('#form-help');

    // === INICIO DE LA VALIDACIÓN MEJORADA ===

    // 1. Validar requeridos y longitud mínima con checkValidity()
    if (!nombre.checkValidity() || !email.checkValidity() || !mensaje.checkValidity()) {
        mostrarNotificacion(helpText, 'Por favor, completa todos los campos correctamente.', 'error');
        submitButton.disabled = false;
        submitButton.textContent = 'Enviar';
        return;
    }
    
    // 2. Definir el patrón (regex) que solo acepta letras, tildes y espacios
    const namePattern = /^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s]+$/;

    // 3. Validar el formato del nombre
    if (!namePattern.test(nombre.value)) {
        mostrarNotificacion(helpText, 'El nombre solo puede contener letras, tildes y espacios.', 'error');
        submitButton.disabled = false;
        submitButton.textContent = 'Enviar';
        return;
    }

    // === FIN DE LA VALIDACIÓN MEJORADA ===

    const formData = new FormData(formulario);
    fetch(formulario.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(respuesta => {
        console.log("Respuesta del servidor (guardar_contacto.php):", respuesta);
        mostrarNotificacion(helpText, respuesta, 'success');
        formulario.reset();
    })
    .catch(error => {
        console.error('Error al enviar el formulario:', error);
        mostrarNotificacion(helpText, 'Error de conexión. No se pudo enviar el mensaje.', 'error');
    })
    .finally(() => {
        submitButton.disabled = false;
        submitButton.textContent = 'Enviar';
    });
}

// ========================================================
// FUNCIÓN 3: Mostrar notificación al usuario
// ========================================================
function mostrarNotificacion(elemento, mensaje, tipo) {
    console.log(`Mostrando notificación: [${tipo}] ${mensaje}`);
    elemento.textContent = mensaje;
    elemento.style.color = tipo === 'success' ? '#a7f3d0' : '#ff8a8a';
}

// ========================================================
// FUNCIÓN 4: Inicializar la sección de Ranking Dinámico
// ========================================================
function inicializarRankingDinamico() {
    console.log("Inicializando funcionalidad de ranking dinámico.");
    const select = document.getElementById('innovacion-select');
    const detalleContainer = document.getElementById('innovacion-detalle');

    // Usamos FETCH para obtener las innovaciones de la BD
    fetch('obtener_innovaciones.php')
        .then(response => {
            if (!response.ok) throw new Error(`Error HTTP! estado: ${response.status}`);
            return response.json();
        })
        .then(innovaciones => {
            console.log("Innovaciones recibidas de la BD:", innovaciones);
            if (innovaciones.length > 0) {
                // Limpiar el select y agregar la opción por defecto
                select.innerHTML = '<option value="">-- Elige una opción --</option>';
                // Llenar el select con los datos
                innovaciones.forEach(innovacion => {
                    const option = document.createElement('option');
                    option.value = innovacion.id;
                    option.textContent = innovacion.nombre;
                    select.appendChild(option);
                });

                // Manejar el evento 'change' para el select.
                // Aquí se asocia el evento a la función.
                select.addEventListener('change', function() {
                    // Pasamos 'this' (el objeto select) y otros parámetros.
                    mostrarDetalleInnovacion(this, innovaciones, detalleContainer);
                });

            } else {
                select.innerHTML = '<option value="">No hay innovaciones para mostrar</option>';
            }
        })
        .catch(error => {
            console.error('Error al cargar las innovaciones:', error);
            detalleContainer.innerHTML = '<p>Hubo un error al cargar los datos del ranking.</p>';
        });
}

// ========================================================
// FUNCIÓN 5: Mostrar detalles de la innovación seleccionada (VERSIÓN CON IMAGEN)
// Esta función usa 3 parámetros.
// ========================================================
function mostrarDetalleInnovacion(selectElement, innovaciones, container) {
    console.log("Mostrando detalle para la innovación seleccionada.");
    const idSeleccionado = selectElement.value; // Obtenemos el ID del <option> seleccionado
    
    // Limpiar el contenedor si no se selecciona nada
    if (!idSeleccionado) {
        container.innerHTML = '';
        return;
    }

    // Buscar la innovación correspondiente en el array usando su ID
    const innovacionEncontrada = innovaciones.find(i => i.id == idSeleccionado); // Usar == para comparación de tipo

    if (innovacionEncontrada) {
        // Generar el HTML con los detalles y la imagen
        container.innerHTML = `
            <figure class="innovacion-figure">
                <img src="${innovacionEncontrada.url_imagen}" alt="${innovacionEncontrada.alt_imagen}" loading="lazy">
                <figcaption>${innovacionEncontrada.nombre}</figcaption>
            </figure>
            <div>
                <h3>${innovacionEncontrada.nombre}</h3>
                <p class="meta"><strong>Categoría:</strong> ${innovacionEncontrada.categoria}</p>
                <p class="meta"><strong>Impacto Estimado:</strong> ${innovacionEncontrada.impacto}</p>
                <p>${innovacionEncontrada.descripcion}</p>
            </div>
        `;
    }
}

// ========================================================
// Funciones de efectos visuales (código original + observer)
// ========================================================
let observer;

function inicializarEfectosVisuales() {
    console.log("Inicializando efectos visuales (scroll, mouse glow, theme switch).");
    
    observer = new IntersectionObserver((entries) => {
        entries.forEach(e => {
            if (e.isIntersecting) e.target.classList.add('visible');
        });
    }, { threshold: .15 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

    document.addEventListener('pointermove', (e) => {
        document.documentElement.style.setProperty('--mx', e.clientX + 'px');
        document.documentElement.style.setProperty('--my', e.clientY + 'px');
    });

    const titulo = document.getElementById('titulo');
    if (titulo) {
        let dark = true;
        titulo.addEventListener('click', function() {
            dark = !dark;
            // Pasamos 'this' (el objeto del título) como parámetro
            cambiarTema(this, dark);
        });
    }
}

function cambiarTema(elemento, esOscuro) {
    console.log(`Cambiando tema. Es oscuro: ${esOscuro}`);
    document.body.style.background = esOscuro
        ? 'radial-gradient(1200px 600px at 20% 10%, #0ff3, transparent), radial-gradient(800px 800px at 80% 0%, #f0f3, transparent), #0d1117'
        : 'linear-gradient(135deg,#0d1117 0%,#1f1144 60%,#2b0f3b 100%)';
}
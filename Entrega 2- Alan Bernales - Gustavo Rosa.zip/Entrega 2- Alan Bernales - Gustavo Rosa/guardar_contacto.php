<?php
// guardar_contacto.php - Procesa y guarda los datos del formulario

require 'conex.php';

// Verificar que los datos lleguen por el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener y limpiar los datos del formulario
    $nombre = trim($_POST['nombre']);
    $email = trim($_POST['email']);
    $mensaje = trim($_POST['mensaje']);

    // Preparar la consulta SQL para evitar inyecciones SQL (MÁXIMA SEGURIDAD)
    $stmt = $conn->prepare("INSERT INTO contactos (nombre, email, mensaje) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nombre, $email, $mensaje);

    // Ejecutar la consulta y notificar al usuario
    if ($stmt->execute()) {
        echo "¡Gracias, $nombre! Tu mensaje ha sido recibido correctamente.";
    } else {
        echo "Error: No se pudo guardar tu mensaje. Por favor, intenta de nuevo.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Error: Método de solicitud no válido.";
}
?>
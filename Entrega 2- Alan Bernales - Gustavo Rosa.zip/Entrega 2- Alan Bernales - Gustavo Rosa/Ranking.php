<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Ranking de las innovaciones tecnológicas más importantes de 2025.">
    <title>Ranking de Innovaciones — TechNews360</title>
    <link rel="stylesheet" href="css/style.css">
    <script defer src="js/script.js"></script>
</head>
<body>
    <header class="header" role="banner">
        <div class="brand glow" id="titulo" tabindex="0" aria-label="TechNews tres sesenta">
            <span class="logo">🌐</span> TechNews360
        </div>
        <nav class="nav" aria-label="Navegación principal">
            <ul class="menu">
                <li><a href="index.php#noticias">Noticias</a></li>
                <li><a href="index.php#videos">Videos</a></li>
                <li><a href="Ranking.php">Ranking</a></li>
                <li><a href="Contacto.php">Contacto</a></li>
            </ul>
        </nav>
    </header>
    <main id="contenido" class="main-ranking">
        <section id="ranking" class="section">
            <h2>Ranking de Innovaciones 2025</h2>
            
            <table aria-describedby="ranking-desc">
                <caption id="ranking-desc">Tendencias y su impacto estimado</caption>
                <thead>
                    <tr>
                        <th>Posición</th>
                        <th>Innovación</th>
                        <th>Impacto</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Agentes de IA</td>
                        <td>Muy alto</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Computación cuántica</td>
                        <td>Alto</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Realidad mixta</td>
                        <td>Medio</td>
                    </tr>
                </tbody>
            </table>

            <h3 class="subtitulo-ranking">Explorar Innovaciones en Detalle</h3>
            
            <div id="ranking-dinamico">
                <div class="field">
                    <label for="innovacion-select">Seleccionar Innovación:</label>
                    <select id="innovacion-select" name="innovacion">
                        <option value="">Cargando innovaciones...</option>
                    </select>
                </div>
                <div id="innovacion-detalle" class="card-body">
                    </div>
            </div>
        </section>
    </main>
    <footer class="footer" role="contentinfo">
        <hr>
        <p>&copy; 2025 TechNews360 — Última actualización: 2025-09-02</p>
    </footer>
</body>
</html>
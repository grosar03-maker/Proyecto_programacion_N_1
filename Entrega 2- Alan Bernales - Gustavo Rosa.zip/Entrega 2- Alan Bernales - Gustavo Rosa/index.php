<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Portal de noticias de tecnología con IA, gadgets, ciberseguridad y ciencia.">
  <title>TechNews360 — Noticias de Tecnología</title>
  <link rel="stylesheet" href="css/style.css">
  <script defer src="js/script.js"></script>
</head>
<body>
  <header class="header" role="banner">
    <div class="brand glow" id="titulo" tabindex="0" aria-label="TechNews tres sesenta">
      <span class="logo">🌐</span> TechNews360
    </div>
    <nav class="nav" aria-label="Navegación principal">
      <ul class="menu">
        <li><a href="#noticias">Noticias</a></li>
        <li><a href="#videos">Videos</a></li>
        <li><a href="Ranking.php">Ranking</a></li>
        <li><a href="Contacto.php">Contacto</a></li>
      </ul>
    </nav>
  </header>

  <main id="contenido">
    <section id="hero" class="hero">
      <h1>Últimas de tecnología, hoy</h1>
      <p>Curadas desde medios reconocidos. Resúmenes claros, enlaces a fuentes, y un diseño <b>rápido</b>, <i>accesible</i> y con <br>animaciones suaves.</p>
      <a class="btn-cta" href="#noticias">Ver titulares</a>
    </section>

    <section id="noticias" class="section">
       <h2>Noticias destacadas</h2>
       <div id="noticias-container">
           </div>
    </section>

    <section id="videos" class="section">
      <h2>Videos recomendados</h2>
      <div class="video-grid">
        <div class="video-card reveal">
          <iframe title="Vergecast Streaming Draft" width="560" height="315" src="https://www.youtube.com/embed/cfpPPL7WDUc" frameborder="0" allowfullscreen></iframe>
          <p class="meta">The Vergecast — Draft de streaming 2025</p>
        </div>
        <div class="video-card reveal">
          <iframe title="Tech en 2025 (Vergecast)" width="560" height="315" src="https://www.youtube.com/embed/kxZz-GaNyZo" frameborder="0" allowfullscreen></iframe>
          <p class="meta">The Vergecast — Tech en 2025</p>
        </div>
      </div>
    </section>
  </main>

  <footer class="footer" role="contentinfo">
    <hr>
    <p>&copy; 2025 TechNews360 — Última actualización: 2025-09-02</p>
    <p>Créditos de imágenes: Unsplash. Fuentes: The Verge, WIRED, Ars Technica.</p>
  </footer>
</body>
</html>
<?php
// obtener_noticias.php - Consulta la BD y devuelve las noticias en formato JSON

require 'conex.php';

$response = [];
$sql = "SELECT id, titulo, descripcion, fuente, fecha_publicacion, url_noticia, url_imagen, alt_imagen FROM noticias ORDER BY id DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $response[] = $row;
    }
}

$conn->close();

// Devolver la respuesta como JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
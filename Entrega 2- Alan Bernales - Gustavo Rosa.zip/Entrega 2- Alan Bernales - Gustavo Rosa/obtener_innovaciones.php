<?php
// obtener_innovaciones.php - Consulta la BD y devuelve las innovaciones en formato JSON

require 'conex.php';

$response = [];
// Asegúrate de seleccionar las nuevas columnas url_imagen y alt_imagen
$sql = "SELECT id, nombre, categoria, impacto, descripcion, url_imagen, alt_imagen FROM innovaciones ORDER BY id ASC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $response[] = $row;
    }
}

$conn->close();

// Devolver la respuesta como JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
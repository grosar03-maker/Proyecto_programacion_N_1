--
-- Base de datos: `A2025_grosa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contactos`
--
CREATE TABLE `contactos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mensaje` text NOT NULL,
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `innovaciones`
--
CREATE TABLE `innovaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `categoria` varchar(100) NOT NULL,
  `impacto` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `url_imagen` varchar(255) DEFAULT NULL,
  `alt_imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `innovaciones`
--
INSERT INTO `innovaciones` (`id`, `nombre`, `categoria`, `impacto`, `descripcion`, `url_imagen`, `alt_imagen`) VALUES
(1, 'Agentes de IA', 'Inteligencia Artificial', 'Muy Alto', 'Sistemas autónomos capaces de percibir su entorno, tomar decisiones y ejecutar acciones complejas para alcanzar objetivos específicos. Están revolucionando desde la atención al cliente hasta la logística.', 'imagenes/ia-agents.jpg', 'Robot interactuando con interfaz de IA'),
(2, 'Computación Cuántica', 'Hardware Avanzado', 'Alto', 'Utiliza los principios de la mecánica cuántica para realizar cálculos a velocidades exponencialmente superiores a las de las computadoras clásicas. Promete resolver problemas hoy intratables en medicina y ciencia de materiales.', 'imagenes/quantum-computing.jpg', 'Representación visual de computación cuántica'),
(3, 'Realidad Mixta (RM)', 'Interfaces de Usuario', 'Medio', 'Fusiona el mundo real y el virtual para crear nuevos entornos e interacciones donde los objetos físicos y digitales coexisten. Es el siguiente paso en la evolución de la realidad virtual y aumentada.', 'imagenes/mixed-reality.jpg', 'Persona con gafas de realidad mixta interactuando con el entorno virtual');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--
CREATE TABLE `noticias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text NOT NULL,
  `fuente` varchar(100) DEFAULT NULL,
  `fecha_publicacion` varchar(100) DEFAULT NULL,
  `url_noticia` varchar(255) NOT NULL,
  `url_imagen` varchar(255) NOT NULL,
  `alt_imagen` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `noticias`
--
INSERT INTO `noticias` (`id`, `titulo`, `descripcion`, `fuente`, `fecha_publicacion`, `url_noticia`, `url_imagen`, `alt_imagen`) VALUES
(1, 'Copilot llega a los televisores Samsung 2025', 'Microsoft integra Copilot en TVs y monitores Samsung para recomendaciones y consultas desde el sofá. Interacción por voz y app dedicada.', 'The Verge', 'publicado hace 5 días', 'https://www.theverge.com/news/767078/microsoft-samsung-tv-copilot-ai-assistant-launch', 'imagenes/noticia-1.jpg', 'Televisores inteligentes con asistente virtual'),
(2, '¿Burbuja de IA? El debate sigue', 'Un análisis sobre expectativas y fricciones alrededor de chatbots y su impacto real en personas y negocios.', 'Ars Technica', 'publicado la semana pasada', 'https://arstechnica.com/information-technology/2025/08/with-ai-chatbots-big-tech-is-moving-fast-and-breaking-people/', 'imagenes/noticia-2.jpg', 'Chatbots de IA y ética tecnológica'),
(3, 'Lo más top del MWC 2025', 'Del smartphone ultradelgado a portátiles solares, un repaso de los dispositivos que marcaron la feria.', 'WIRED', 'publicado hace 6 meses', 'https://www.wired.com/story/top-gadgets-at-mwc-2025/', 'imagenes/noticia-3.jpg', 'Gadgets y móviles en MWC'),
(4, 'Genie 3 crea mundos jugables en tiempo real', 'DeepMind presenta un modelo capaz de generar entornos 3D interactivos con memoria persistente.', 'The Verge', 'publicado hace 4 semanas', 'https://www.theverge.com/news/718723/google-ai-genie-3-model-video-game-worlds-real-time', 'imagenes/noticia-4.jpg', 'Mundos 3D generados por IA');
<?php
// conex.php - Archivo de conexión a la base de datos

// --- Credenciales para la conexión en Pillan ---
$host = "mysql.inf.uct.cl";
$user = "grosa";
$pass = "Gustavito-06";
$db   = "A2025_grosa";

// Crear la conexión usando el estilo orientado a objetos (más moderno y recomendado)
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si hubo un error en la conexión
if ($conn->connect_error) {
    // Detener la ejecución y mostrar un mensaje de error claro si la conexión falla.
    // 'die()' es una forma segura de terminar el script para que no continúe con errores.
    die("Error de conexión a la BD: " . $conn->connect_error);
}

// Establecer el juego de caracteres a UTF-8.
// Esto es muy importante para que las tildes y la 'ñ' se guarden y muestren correctamente.
$conn->set_charset("utf8");

// No es necesario un 'echo "conexión correcta";' aquí,
// ya que si el script continúa, significa que la conexión fue exitosa.
// Mostrar mensajes de éxito en producción no es una buena práctica.
?>
// =========================================================================
// ARCHIVO: script.js
// CUMPLE CON TODOS LOS REQUISITOS DE LA ENTREGA 2 (CON CORRECCIÓN)
// =========================================================================

document.addEventListener('DOMContentLoaded', () => {
    console.log("DOM completamente cargado. Inicializando scripts.");

    const noticiasContainer = document.getElementById('noticias-container');
    if (noticiasContainer) {
        cargarNoticias(noticiasContainer, 'obtener_noticias.php');
    }

    const form = document.getElementById('formulario');
    if (form) {
        form.addEventListener('submit', function(ev) {
            manejarEnvioFormulario(ev, this);
        });
    }

    inicializarEfectosVisuales();
});

// ========================================================
// FUNCIÓN 1: Cargar noticias usando FETCH
// ========================================================
function cargarNoticias(container, url) {
    console.log(`Iniciando fetch de noticias desde: ${url}`);
    
    fetch(url)
        .then(response => {
            if (!response.ok) throw new Error(`Error HTTP! estado: ${response.status}`);
            return response.json();
        })
        .then(noticias => {
            console.log("Noticias recibidas de la BD:", noticias);
            if (noticias.length === 0) {
                container.innerHTML = '<p>No hay noticias para mostrar en este momento.</p>';
                return;
            }
            
            container.innerHTML = ''; // Limpiar el contenedor

            noticias.forEach(noticia => {
                const card = document.createElement('article');
                card.className = 'card reveal';
                card.setAttribute('aria-labelledby', `title-${noticia.id}`);
                card.innerHTML = `
                    <figure>
                        <img src="${noticia.url_imagen}" alt="${noticia.alt_imagen}" loading="lazy">
                        <figcaption>Foto: Unsplash</figcaption>
                    </figure>
                    <div class="card-body">
                        <h3 id="title-${noticia.id}">${noticia.titulo}</h3>
                        <p>${noticia.descripcion}</p>
                        <p class="meta">Fuente: ${noticia.fuente} — ${noticia.fecha_publicacion}</p>
                        <a class="btn" target="_blank" rel="noopener" href="${noticia.url_noticia}">Leer en ${noticia.fuente}</a>
                    </div>
                `;
                container.appendChild(card);
            });
            
            document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
        })
        .catch(error => {
            console.error('Error al cargar las noticias:', error);
            container.innerHTML = '<p>Hubo un error al cargar las noticias. Revisa la consola para más detalles.</p>';
        });
}

// ========================================================
// FUNCIÓN 2: Manejar el envío del formulario (VERSIÓN CORREGIDA)
// ========================================================
function manejarEnvioFormulario(evento, formulario) {
    console.log("Interceptando envío de formulario...");
    evento.preventDefault();

    // --- PASO 1: Seleccionar el botón y deshabilitarlo ---
    const submitButton = formulario.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.textContent = 'Enviando...';

    const nombre = formulario.querySelector('#nombre');
    const email = formulario.querySelector('#email');
    const mensaje = formulario.querySelector('#mensaje');
    const helpText = formulario.querySelector('#form-help');

    if (!nombre.checkValidity() || !email.checkValidity() || !mensaje.checkValidity()) {
        mostrarNotificacion(helpText, 'Por favor, completa todos los campos correctamente.', 'error');
        submitButton.disabled = false;
        submitButton.textContent = 'Enviar';
        return;
    }

    const formData = new FormData(formulario);
    fetch(formulario.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(respuesta => {
        console.log("Respuesta del servidor (guardar_contacto.php):", respuesta);
        mostrarNotificacion(helpText, respuesta, 'success');
        formulario.reset();
    })
    .catch(error => {
        console.error('Error al enviar el formulario:', error);
        mostrarNotificacion(helpText, 'Error de conexión. No se pudo enviar el mensaje.', 'error');
    })
    .finally(() => {
        // --- PASO 2: Reactivar el botón al finalizar (éxito o error) ---
        submitButton.disabled = false;
        submitButton.textContent = 'Enviar';
    });
}

// ========================================================
// FUNCIÓN 3: Mostrar notificación al usuario
// ========================================================
function mostrarNotificacion(elemento, mensaje, tipo) {
    console.log(`Mostrando notificación: [${tipo}] ${mensaje}`);
    elemento.textContent = mensaje;
    elemento.style.color = tipo === 'success' ? '#a7f3d0' : '#ff8a8a';
}

// ========================================================
// Funciones de efectos visuales (código original + observer)
// ========================================================
let observer;

function inicializarEfectosVisuales() {
    console.log("Inicializando efectos visuales (scroll, mouse glow, theme switch).");
    
    observer = new IntersectionObserver((entries) => {
        entries.forEach(e => {
            if (e.isIntersecting) e.target.classList.add('visible');
        });
    }, { threshold: .15 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

    document.addEventListener('pointermove', (e) => {
        document.documentElement.style.setProperty('--mx', e.clientX + 'px');
        document.documentElement.style.setProperty('--my', e.clientY + 'px');
    });

    const titulo = document.getElementById('titulo');
    if (titulo) {
        let dark = true;
        titulo.addEventListener('click', function() {
            dark = !dark;
            cambiarTema(this, dark);
        });
    }
}

function cambiarTema(elemento, esOscuro) {
    console.log(`Cambiando tema. Es oscuro: ${esOscuro}`);
    document.body.style.background = esOscuro
        ? 'radial-gradient(1200px 600px at 20% 10%, #0ff3, transparent), radial-gradient(800px 800px at 80% 0%, #f0f3, transparent), #0d1117'
        : 'linear-gradient(135deg,#0d1117 0%,#1f1144 60%,#2b0f3b 100%)';
}